# WeatherTime/Strings.pm
# $Id: Strings.pm 101 2008-05-04 22:13:05Z martin.rehfeld@glnetworks.de $
#
#	Author: Martin Rehfeld <martin.rehfeld(at)glnetworks(dot)de>
#
#	Copyright (c) 2005-2007
#	This file is part of the WeatherTime software. The same license applies.
#	See main file Plugin.pm for details
#

package Plugins::WeatherTime::Strings;
use strict;

sub strings { return '
PLUGIN_SCREENSAVER_WEATHERTIME
	DE	Wetter/Zeit Bildschirmschoner
	EN	Weather, Date and Time
	FR	Température, Date et Heure
	NL	Weer, datum en tijd
	SE	Väder, datum och tid
	DA	Vejr, dato og tid
	
PLUGIN_SCREENSAVER_WEATHERTIME_START
	DE	PLAY drücken zum Starten des Bildschirmschoners
	EN	Press PLAY to start this screensaver
	FR	Appuyez sur PLAY pour activer cet écran de veille
	NL	Druk op PLAY om deze schermbeveiliger aan te zetten
	SE	Tryck PLAY för att aktivera skärmsläckaren
	DA	Tryk PLAY for at starte screensaver

PLUGIN_SCREENSAVER_WEATHERTIME_ENABLE
	DE	PLAY drücken zum Aktivieren des Bildschirmschoners
	EN	Press PLAY to enable this screensaver
	FR	Appuyez sur PLAY pour activer cet écran de veille
	NL	Druk op PLAY om deze schermbeveiliger aan te zetten
	SE	Tryck PLAY för att aktivera skärmsläckaren
	DA	Tryk PLAY for at aktivere screensaver

PLUGIN_SCREENSAVER_WEATHERTIME_DISABLE
	DE	PLAY drücken zum Deaktivieren dieses Bildschirmschoners
	EN	Press PLAY to disable this screensaver
	FR	Appuyer sur PLAY pour désactiver cet écran de veille
	NL	Druk op PLAY om deze schermbeveiliger uit te zetten
	SE	Tryck PLAY för att inaktivera skärmsläckaren
	DA	Tryk PLAY for at inaktivere screensaver

PLUGIN_SCREENSAVER_WEATHERTIME_ENABLING
	DE	Wetter/Zeit Bildschirmschoner aktivieren
	EN	Enabling WeatherTime as current screensaver
	FR	Activation de WeatherTime comme écran de veille actuel
	NL	Aanzetten van Weer, datum en tijd als huidige schermbeveiliger
	SE	Aktiverar WeatherTime som skärmsläckare
	DA	Aktiver WeatherTime som screensaver

PLUGIN_SCREENSAVER_WEATHERTIME_DISABLING
	DE	Standard-Bildschirmschoner deaktivieren
	EN	Resetting to default screensaver
	FR	Retour à l\'écran de veille par défaut
	NL	Herstellen standaard schermbeveiliger
	SE	Återställer till default skärmsläckare
	DA	Reset til default screensaver

PLUGIN_SCREENSAVER_WEATHERTIME_UPDATING
	DE	Aktualisiere aktuelle Wetterdaten...
	EN	Updating Weather Forecast...
	FR	Mise à jour des prévisions météo...
	NL	Bijwerken weersvoorspelling
	SE	Uppdaterar väderprognos...
	DA	Opdaterer vejr prognose

PLUGIN_SCREENSAVER_NOSETUP_LINE1
	DE	Setup erforderlich
	EN	Setup Required
	FR	Configuration requis
	NL	Instellen noodzakelijk
	SE	Inställningar krävs
	DA	Setup kræves

PLUGIN_SCREENSAVER_NOSETUP_LINE2
	DE  Server settings eintragen.
	EN	Enter server settings.
	FR	Entrez dans les paramètres de serveur.
	NL	Enter in server instellingen
	SE	(server-inställningar)
	DA	(server-indstilninger).

SETUP_GROUP_PLUGIN_WEATHERTIME
	DE	Wetter/Zeit Bildschirmschoner
	EN	Weather, Date and Time Screensaver
	FR	Ecran de veille Température, Date et Heure
	NL	Weer, datum en tijd schermbeveiliger
	SE	Väder, datum och tid skärmsläckare
	DA	Vejr, dato og tid screensaver

SETUP_GROUP_PLUGIN_WEATHERTIME_DESC
	EN	The weather data is retrieved from <i>Weather Underground&reg;</i>. To localize your forecast you also need to find out a unambiguous wunderground.com citycode. It is advisable to use the 3-letter-code of your nearest airport, e.g. TXL for Berlin-Tegel, Germany.
	FR	L\'information météo est extraite de <i>Weather Underground&reg;</i>. Pour localiser vos prévisions vous devez aussi déterminer le code de ville de wunderground.com, par exemple YUL pour Montréal, Canada (Airport-Code).
	DE	Die Wetterdaten werden von <i>Weather Underground&reg;</i> bezogen. Der Citycode stammt ebenfalls von wunderground.com, zum Beispiel TXL für Berlin-Tegel (es empfiehlt sich, den 3-Buchstabencode des nächstgelegenen Flughafens zu verwenden).
	NL	Het weerbericht is opgehaald van  <i>Weather Underground&reg;</i>. Om het weerbericht te localiseren heb je de citycode van wunderground.com nodig. Bijvoorbeeld AMS voor Amsterdam-Schiphol (Airport-Code).
	SE	Väderprognos hämtas från <i>Weather Underground&reg;</i>. To localize your forecast you also need to find out a unambiguous wunderground.com citycode. It is advisable to use the 3-letter-code of your nearest airport, e.g. TXL for Berlin-Tegel, Germany.
	DA	Vejrprognosen hentes fra <i>Weather Underground&reg;</i>. For lokal prognose skal du finde wunderground.com by koden, f.eks RKE for Roskilde, Danmark (Airport-Code).

SETUP_PLUGIN_WEATHERTIME_UNITS
	EN	Weather Units
	FR	Unités Météo
	DE	Einheiten
	NL	Eenheden
	SE	Enheter
	DA	Enheder

SETUP_PLUGIN_WEATHERTIME_1
	EN	Metric Units
	FR	Unités Métriques
	DE	metrisch
	NL	Metrisch
	SE	Meter
	DA	Meter

SETUP_PLUGIN_WEATHERTIME_0
	EN	Imperial Units
	FR	Unités Impériales
	DE	englisch
	NL	Engels
	SE	Engelska enheter
	DA	Engelske enheder

SETUP_PLUGIN_WEATHERTIME_LINETHREE
	EN	Third line
	DA	Tredje linie
	DE	Dritte Zeile

SETUP_PLUGIN_WEATHERTIME_LINETHREE_0
	EN	Precipitation chance
	DA	Risiko for regn
	DE	Regenwahrscheinlichkeit

SETUP_PLUGIN_WEATHERTIME_LINETHREE_1
	EN	Wind info
	DA	Vind info
	DE	Windrichtung

SETUP_PLUGIN_WEATHERTIME_LINETHREE_UNIT
	EN	Wind info units
	DA	Vind info enheder
	DE	Wind-Einheit

SETUP_PLUGIN_WEATHERTIME_LINETHREE_UNIT_0
	EN	Meters pr. second
	DA	Meter pr. sekund
	DE	Meter pro Sekunde

SETUP_PLUGIN_WEATHERTIME_LINETHREE_UNIT_1
	EN	Kilometers pr. hour
	DA	Kilometer i timen
	DE	Kilometer pro Stunde

SETUP_PLUGIN_WEATHERTIME_LINETHREE_UNIT_2
	EN	Miles pr. hour
	DA	Miles i timen
	DE	Meilen pro Stunde

SETUP_PLUGIN_WEATHERTIME_CITY
	EN	City
	FR	Ville
	DE	Name der Stadt
	NL	Plaatsnaam
	SE	Stad
	DA	By

SETUP_PLUGIN_WEATHERTIME_CITYCODE
	EN	Wunderground.com Citycode
	FR	Code de ville Wunderground.com
	DE	Wunderground.com Citycode
	NL	Wunderground.com Citycode
	SE	Wunderground.com stadskod
	DA	Wunderground.com bykode

SETUP_PLUGIN_WEATHERTIME_INTERVAL
	EN	Fetch Interval (seconds)
	FR	Intervalle de mise-à-jour (secondes)
	DE	Aktualisierungsintervall (sekunden)
	NL	Interval voor bijwerken in seconden
	SE	Uppdateringsfrekvens (sekunder)
	DA	Uppdateringsfrekvens (sekunder)

SETUP_PLUGIN_WEATHERTIME_DATEFORMAT
	EN	Date format
	FR	Format des dates
	DE	Datumsformat
	NL	Datumformaat
	SE	Datumformat
	DA	Datoformat

SETUP_PLUGIN_WEATHERTIME_STDDATE
	EN	standard
	FR	standard
	DE	Standardformat
	NL	standaardformat
	SE	standard
	DA	standard

SETUP_PLUGIN_WEATHERTIME_NODATE
	EN	no date (time only)
	FR	sans date (heure seulement)
	DE	kein Datum (nur Zeit)
	NL	geen datum (alleen de tijd)
	SE	inget datum (endast tid)
	DA	ingen dato (kun tid)

PLUGIN_SCREENSAVER_WEATHERTIME_NOINFO
	DE	Lade...
	EN	loading...
	FR	Chargement...
	NL	Laden...
	SE	hämtas...
	DA	hentes...

PLUGIN_WEATHERTIME_NO_FORECAST_AVAILABLE
	DE	keine Vorhersage vorhanden
	EN	no forecast available
	FR	Prévisions non disponibles
	NL	geen weerbericht beschikbaar
	SE	Ingen prognos tillgänglig
	DA	Ingen prognose tilgængelig

PLUGIN_WEATHERTIME_CURRENTTEMP
	DE	Jetzt
	EN	Now
	FR	Maintenant
	NL	Nu
	SE	Nu
	DA	Nu

PLUGIN_WEATHERTIME_TODAY
	DE	Heute
	EN	Today
	FR	Aujourd\'hui
	NL	Vandaag
	SE	Idag
	DA	I dag

PLUGIN_WEATHERTIME_TONIGHT
	DE	Nachts
	EN	Tonight
	FR	Ce soir
	NL	Vannacht
	SE	Ikväll
	DA	I aften

PLUGIN_WEATHERTIME_TOMORROW
	DE	Morgen
	EN	Tomorrow
	FR	Demain
	NL	Morgen
	SE	Imorgon
	DA	I morgen

PLUGIN_WEATHERTIME_SUNDAY
	DE	Sonntag
	EN	Sunday
	FR	Dimanche
	NL	Zondag
	SE	Söndag
	DA	Søndag

PLUGIN_WEATHERTIME_MONDAY
	DE	Montag
	EN	Monday
	FR	Lundi
	NL	Maandag
	SE	Måndag
	DA	Mandag

PLUGIN_WEATHERTIME_TUESDAY
	DE	Dienstag
	EN	Tuesday
	FR	Mardi
	NL	Dinsdag
	SE	Tisdag
	DA	Tirsdag

PLUGIN_WEATHERTIME_WEDNESDAY
	DE	Mittwoch
	EN	Wednesday
	FR	Mercredi
	NL	Woensdag
	SE	Onsdag
	DA	Onsdag

PLUGIN_WEATHERTIME_THURSDAY
	DE	Donnerstag
	EN	Thursday
	FR	Jeudi
	NL	Donderdag
	SE	Torsdag
	DA	Torsdag

PLUGIN_WEATHERTIME_FRIDAY
	DE	Freitag
	EN	Friday
	FR	Vendredi
	NL	Vrijdag
	SE	Fredag
	DA	Fredag

PLUGIN_WEATHERTIME_SATURDAY
	DE	Samstag
	EN	Saturday
	FR	Samedi
	NL	Zaterdag
	SE	Lördag
	DA	Lørdag

PLUGIN_WEATHERTIME_NIGHT
	DE	Nachts
	EN	Night
	FR	Nuit
	NL	\'s Nachts
	SE	Natt
	DA	Nat

PLUGIN_WEATHERTIME_DAY
	DE	Tags�ber
	EN	Day
	FR	Jour
	NL	Overdag
	SE	Dag
	DA	Dag

PLUGIN_WEATHERTIME_HIGH
	DE	Max
	EN	High
	FR	Maximum
	NL	Max
	SE	Max
	DA	Maks

PLUGIN_WEATHERTIME_LOW
	DE	Min
	EN	Low
	FR	Minimum
	NL	Min
	SE	Min
	DA	Min

PLUGIN_WEATHERTIME_PRECIP
	DE	Regen
	EN	Precip
	FR	Précip
	NL	Regen
	SE	Nederbörd
	DA	NedbØr

PLUGIN_WEATHERTIME_CLOUDY
	EN	Cloudy
	FR	Nuageux
	DE	bewölkt
	NL	zwaarbewolkt
	SE	Mulet
	DA	Skyet

PLUGIN_WEATHERTIME_MOSTLY_CLOUDY
	EN	Mostly Cloudy
	FR	Plutôt nuageux
	DE	meist bewölkt
	NL	bewolkt
	SE	Övervägande mulet
	DA	Mest skyet

PLUGIN_WEATHERTIME_PARTLY_CLOUDY
	EN	Partly Cloudy
	FR	Partiellement nuageux
	DE	teilw. bewölkt
	NL	halfbewolkt
	SE	Halvklart
	DA	Let skyet

PLUGIN_WEATHERTIME_LIGHT_RAIN
	EN	Light Rain
	FR	Pluie légère
	DE	etwas Regen
	NL	enige regen
	SE	Lätt regn
	DA	Let regn

PLUGIN_WEATHERTIME_LIGHT_RAIN_WIND
	EN	Light Rain / Wind
	FR	Pluie légère / Vent
	DE	etwas Regen, Wind
	NL	enige regen / winderig
	SE	Lätt regn / vind
	DA	Let regn/blæst

PLUGIN_WEATHERTIME_SHOWERS
	EN	Showers
	FR	Averses
	DE	Schauer
	NL	buien
	SE	Skurar
	DA	Byger

PLUGIN_WEATHERTIME_RAIN
	EN	Rain
	FR	Pluie
	DE	Regen
	NL	regen
	SE	Regn
	DA	Regn

PLUGIN_WEATHERTIME_AM_SHOWERS
	EN	AM Showers
	FR	Averses AM
	DE	Vorm. Schauer
	NL	ocht. buien
	SE	fm. skurar
	DA	fm. byger

PLUGIN_WEATHERTIME_SHOWERS_EARLY
	EN	Showers early
	FR	Averses Tôt
	DE	anfangs Schauer
	NL	vroeg buien
	SE	fm. skurar
	DA	byger fm.

PLUGIN_WEATHERTIME_SHOWERS_LATE
	EN	Showers late
	FR	Averses Tard
	DE	abends Schauer
	NL	avond buien
	SE	em. skurar
	DA	byger em.

PLUGIN_WEATHERTIME_FOG
	EN	Fog
	FR	Brouillard
	DE	Nebel
	NL	mist
	SE	Dimma
	DA	TÅGE

PLUGIN_WEATHERTIME_FEW_SHOWERS
	EN	Few Showers
	FR	Quelques Averses
	DE	vereinzelte Schauer
	NL	enkele buien
	SE	Enstaka skurar
	DA	Enkelte byger

PLUGIN_WEATHERTIME_MOSTLY_SUNNY
	EN	Mostly Sunny
	FR	Plutôt Ensoleillé
	DE	meist sonnig
	NL	vooral zonnig
	SE	Övervägande soligt
	DA	Mest solrigt

PLUGIN_WEATHERTIME_SUNNY
	EN	Sunny
	FR	Ensoleillé
	DE	sonnig
	NL	zonnig
	SE	Soligt
	DA	Solrigt

PLUGIN_WEATHERTIME_SCATTERED_FLURRIES
	EN	Scattered Flurries
	FR	Neige Passagère
	DE	Böen aus wechselnder Richtung
	NL	lokaal buien
	SE	Lokala regnbyar
	DA	Lokale byger

PLUGIN_WEATHERTIME_AM_CLOUDS_PM_SUN
	EN	AM Clouds/PM Sun
	FR	Nuageux AM / Soleil PM
	DE	Vorm. Wolken, nachm. Sonne
	NL	bewolkt later zonnig
	SE	Uppsprickande molntäcke
	DA	Skyet senere sol

PLUGIN_WEATHERTIME_CLOUDS_EARLY_CLEARING_LATE
	EN	Clouds Early / Clearing Late
	FR	Nuages Tôt / Eclaircissements
	DE	anfangs Wolken / abends klar
	NL	bewolkt later opklaringen
	SE	Uppsprickande molntäcke
	DA	Skyet senere opklaring

PLUGIN_WEATHERTIME_ISOLATED_T-STORMS
	EN	Isolated T-Storms
	FR	Orages Isolées
	DE	vereinzelte Gewitter
	NL	een enkele onweersbui
	SE	Enstaka åskväder
	DA	Enkelte tordenbyger

PLUGIN_WEATHERTIME_SCATTERED_THUNDERSTORMS
	EN	Scattered Thunderstorms
	FR	Orages Dispersées
	DE	verteilte Gewitter
	NL	lokaal onweersbuien
	SE	Lokala åskväder
	DA	Lokal storm

PLUGIN_WEATHERTIME_SCATTERED_T-STORMS
	EN	Scattered Thunderstorms
	FR	Orages Dispersées
	DE	verteilte Gewitter
	NL	lokaal onweersbuien
	SE	Lokala åskväder
	DA	Lokal torden

PLUGIN_WEATHERTIME_SCATTERED_SHOWERS
	EN	Scattered Showers
	FR	Averses Dispersées
	DE	verteilte Schauer
	NL	lokaal buien
	SE	Lokala skurar
	DA	Lokale byger

PLUGIN_WEATHERTIME_PM_SHOWERS
	EN	PM Showers
	FR	Averses PM
	DE	Nachm. Schauer
	NL	middag buien
	SE	em. skurar
	DA	Em. byger

PLUGIN_WEATHERTIME_PM_SHOWERS_WIND
	EN	PM Showers/Wind
	FR	Averses/Vent PM
	DE	Nachm. Schauer/Wind
	NL	midd. buien/winderig
	SE	em. skurar, vind
	DA	em. byger og blæst

PLUGIN_WEATHERTIME_RAIN_SNOW_SHOWERS
	EN	Rain/Snow Showers
	FR	Averses Pluie/Neige
	DE	Regen/Schneeschauer
	NL	regen/sneeuwbuien
	SE	Regn/Snö
	DA	Regn/sne byger

PLUGIN_WEATHERTIME_FEW_SNOW_SHOWERS
	EN	Few Snow Showers
	FR	Quelques Averses de Neige
	DE	vereinzelte Schneeschauer
	NL	enkele sneeuwbuien
	SE	enstaka snöfall
	DA	Enkelte snebyger

PLUGIN_WEATHERTIME_CLOUDY_WIND
	EN	Cloudy/Wind
	FR	Nuageux/Venteux
	DE	bewölkt/windig
	NL	zwaarbewolkt/winderig
	SE	Mulet/blåst
	DA	Skyer/Blæst

PLUGIN_WEATHERTIME_FLURRIES_WIND
	EN	Flurries/Wind
	FR	Neige/Vent
	DE	böeig/windig
	NL	windvlagen
	SE	Byig vind
	DA	Hård vind

PLUGIN_WEATHERTIME_MOSTLY_CLOUDY_WINDY
	EN	Mostly Cloudy/Windy
	FR	Plutôt Nuageux/Venteux
	DE	meist bewölkt/windig
	NL	bewolkt/winderig
	SE	Övervägande mulet/blåsigt
	DA	Mest Skyet/blæsende

PLUGIN_WEATHERTIME_MOSTLY_CLOUDY_WIND
	EN	Mostly Cloudy/Wind
	FR	Plutôt Nuageux/Venteux
	DE	meist bewölkt/windig
	NL	bewolkt/winderig
	SE	Övervägande mulet/blåsigt
	DA	Mest Skyet/blæsende

PLUGIN_WEATHERTIME_RAIN_THUNDER
	EN	Rain/Thunder
	FR	Pluie/Orages
	DE	Regen/Gewitter
	NL	regen/onweer
	SE	Regn/åska
	DA	Regn/Torden

PLUGIN_WEATHERTIME_PARTLY_CLOUDY_WIND
	EN	Partly Cloudy/Wind
	FR	Partiellement Nuageux/Venteux
	DE	teilw. bewölkt/Wind
	NL	halfbewolkt/winderig
	SE	Delvis mulet/vind
	DA	Let skyet/blæsende

PLUGIN_WEATHERTIME_AM_RAIN_SNOW_SHOWERS
	EN	AM Rain/Snow Showers
	FR	Pluie/Averses de neige AM
	DE	Vorm. Regen/Schneeschauer
	NL	ocht. regen/sneeuwbui
	SE	em. Regn/snö
	DA	Em. Regn/Sne

PLUGIN_WEATHERTIME_SHOWERS_WIND
	EN	Showers/Wind
	FR	Averses/Vent
	DE	Schauer/Wind
	NL	buien/winderig
	SE	Regn/blåst
	DA	Regn/Blæst

PLUGIN_WEATHERTIME_MOSTLY_SUNNY_WIND
	EN	Mostly Sunny/Wind
	FR	Plutôt Ensoleillé/Vent
	DE	meist sonnig/Wind
	NL	vooral zonnig/winderig
	SE	Övervägande soligt/vind
	DA	Mest solrigt/blæsende

PLUGIN_WEATHERTIME_FLURRIES
	EN	Flurries
	FR	Neige
	DE	Böen
	NL	buien
	SE	Byar
	DA	Byger

PLUGIN_WEATHERTIME_RAIN_WIND
	EN	Rain/Wind
	FR	Pluie/Vent
	DE	Regen/Wind
	NL	regen/winderig
	SE	Regn/vind
	DA	Regn/Blæst

PLUGIN_WEATHERTIME_SCT_FLURRIES_WIND
	EN	Sct Flurries/Wind
	FR	Averses de Neige/Vent
	DE	verteilte, böeige Winde
	NL	lokaal buien/winderig
	SE	Lokala vindbyar
	DA	Lokal blæst

PLUGIN_WEATHERTIME_SCT_STRONG_STORMS
	EN	Sct Strong Storms
	FR	Fortes Tempêtes Dispersées
	DE	verteilte, heftige Stürme
	NL	lokaal zware stormen
	SE	Lokala stormar
	DA	Lokal hård storm

PLUGIN_WEATHERTIME_PM_T-STORMS
	EN	PM T-Storms
	FR	Orages PM
	DE	Nachm. Gewitter
	NL	midd. onweersbuien
	SE	em. åska
	DA	Em. torden

PLUGIN_WEATHERTIME_T-STORMS
	EN	T-Storms
	FR	Orages
	DE	Gewitter
	NL	onweersbuien
	SE	Åska
	DA	Torden

PLUGIN_WEATHERTIME_THUNDERSTORMS
	EN	Thunderstorms
	FR	Orages
	DE	Gewitter
	NL	onweer
	SE	Stormar med åska
	DA	Torden og Storm

PLUGIN_WEATHERTIME_SUNNY_WINDY
	EN	Sunny/Windy
	FR	Ensoleillé/Venteux
	DE	sonnig/windig
	NL	zonnig/winderig
	SE	Soligt men blåsigt
	DA	Solrigt/blæsende

PLUGIN_WEATHERTIME_AM_THUNDERSTORMS
	EN	AM Thunderstorms
	FR	Orages AM
	DE	Vorm. Gewitter
	NL	ocht. onweersbuien
	SE	fm. åskskurar
	DA	fm. tordenbyger

PLUGIN_WEATHERTIME_AM_RAIN
	EN	AM Rain
	FR	Pluie AM
	DE	Vorm. Regen
	NL	ochtend regen
	SE	fm. regn
	DA	fm. regn

PLUGIN_WEATHERTIME_ISO_T-Storms_WIND
	EN	Iso T-Storms/Wind
	FR	Orages/Vent Dispersés
	DE	vereinzelte Gewitter/Wind
	NL	enkele onweersbui/winderig
	SE	Lokala stormar/åska 
	DA	Lokal Torden/blæst

PLUGIN_WEATHERTIME_RAIN_SNOW
	EN	Rain/Snow
	FR	Pluie/Neige
	DE	Regen/Schnee
	NL	regen/sneeuw
	SE	Regn/snö
	DA	Regn/Sne

PLUGIN_WEATHERTIME_RAIN_SNOW_WIND
	EN	Rain/Snow/Wind
	FR	Pluie/Neige/Vent
	DE	Regen/Schnee/Wind
	NL	regen/sneeuw/winderig
	SE	Regn/snö/vind
	DA	Regn/Sne/Blæst

PLUGIN_WEATHERTIME_SCT_T-STORMS_WIND
	EN	Sct T-Storms/Wind
	FR	Orages Dispersés/Vent
	DE	verteilte Gewitter/Wind
	NL	lokaal onweersbui/winderig
	SE	Lokala åskbyar, blåst
	DA	Lokal torden/blæst

PLUGIN_WEATHERTIME_AM_SHOWERS_WIND
	EN	AM Showers/Wind
	FR	Averses/Vent AM
	DE	Vorm. Schauer/Wind
	NL	ocht. buien/winderig
	SE	fm. skurar/blåst
	DA	fm. Byger/Blæst

PLUGIN_WEATHERTIME_SHOWERS_WIND_EARLY
	EN	AM Showers/Wind
	FR	Averses/Vent AM
	DE	Vorm. Schauer/Wind
	NL	ocht. buien/winderig
	SE	fm. skurar/blåst
	DA	fm. Byger/Blæst

PLUGIN_WEATHERTIME_SCT_SNOW_SHOWERS
	EN	Sct Snow Showers
	FR	Averses de Neige Dispersées
	DE	verteilte Schneeschauer
	NL	lokaal sneeuwbuien
	SE	Lokalt snöfall
	DA	Lokale snebyger

PLUGIN_WEATHERTIME_SCATTERED_SNOW_SHOWERS
	EN	Scattered Snow Showers
	FR	Averses de Neige Dispersées
	DE	verteilte Schneeschauer
	NL	lokaal sneeuwbuien
	SE	Lokalt snöfall
	DA	Lokale snebyger

PLUGIN_WEATHERTIME_SNOW_TO_ICE_WIND
	EN	Snow to Ice/Wind
	FR	Neige à Glace/Vent
	DE	Schnee in Hagel überg./Wind
	NL	sneeuw tot hagel/winderig
	SE	Snö / hagel vind
	DA	Sne og hagl/blæst

PLUGIN_WEATHERTIME_SNOW_TO_RAIN
	EN	Snow to Rain
	FR	Neige à Pluie
	DE	Schnee in Regen überg.
	NL	sneeuw tot regen
	SE	Snö eller regn
	DA	Sne eller Regn

PLUGIN_WEATHERTIME_AM_LIGHT_RAIN
	EN	AM Light Rain
	FR	Pluie Légère AM
	DE	Vorm. etwas Regen
	NL	ocht. enige regen
	SE	fm. lätt regn
	DA	fm. let regn

PLUGIN_WEATHERTIME_PM_LIGHT_RAIN
	EN	PM Light Rain
	FR	Pluie Légère PM
	DE	Nachm. etwas Regen
	NL	midd. enige regen
	SE	em. lätt regn
	DA	em. let regn

PLUGIN_WEATHERTIME_LIGHT_RAIN_LATE
	EN	Light Rain Late
	FR	Pluie Légère Tard
	DE	Abends etwas Regen
	NL	avond enige regen
	SE	em. lätt regn
	DA	em. let regn

PLUGIN_WEATHERTIME_RAIN_LATE
	EN	Rain Late
	FR	Pluie Tard
	DE	Abends Regen
	NL	avond regen
	SE	em. regn
	DA	em. regn

PLUGIN_WEATHERTIME_PM_RAIN
	EN	PM Rain
	FR	Pluie PM
	DE	Nachm. Regen
	NL	midd. regen
	SE	em. regn
	DA	em. regn

PLUGIN_WEATHERTIME_SNOW_SHOWERS
	EN	Snow Showers
	FR	Averses de Neige
	DE	Schneeschauer
	NL	sneeuwbuien
	SE	Enstaka snöfall
	DA	Snebyger

PLUGIN_WEATHERTIME_SNOW_SHOWER
	EN	Snow Shower
	FR	Averse de Neige
	DE	Schneeschauer
	NL	sneeuwbui
	SE	Enstaka snöfall
	DA	Snebyger

PLUGIN_WEATHERTIME_RAIN_TO_SNOW
	EN	Rain to Snow
	FR	Pluie à Neige
	DE	Regen in Schnee überg.
	NL	regen tot sneeuw
	SE	Snöblandat regn
	DA	Regn måske sne

PLUGIN_WEATHERTIME_PM_RAIN_SNOW
	EN	PM Rain/Snow
	FR	Pluie/Neige PM
	DE	Nachm. Regen/Schnee
	NL	midd. regen/sneeuw
	SE	em. regn/snö
	DA	em. regn/sne

PLUGIN_WEATHERTIME_FEW_SHOWERS_WIND
	EN	Few Showers/Wind
	FR	Quelques Averses/Vent
	DE	wenige Schauer/Wind
	NL	enkele buien/winderig
	SE	Enstaka skurar/blåst
	DA	Enkelte byger/blæst

PLUGIN_WEATHERTIME_SNOW_WIND
	EN	Snow/Wind
	FR	Neige/Vent
	DE	Schnee/Wind
	NL	sneeuw/winderig
	SE	Snö/blåst
	DA	Sne/Blæst

PLUGIN_WEATHERTIME_PM_RAIN_SNOW_SHOWERS
	EN	PM Rain/Snow Showers
	FR	Averses de Pluie/Neige PM
	DE	Nachm. Regen/Schneeschauer
	NL	midd. regen/sneeuwbuien
	SE	em. skurar regn/snö
	DA	em. Regn/Snebyger

PLUGIN_WEATHERTIME_PM_RAIN_SNOW_WIND
	EN	PM Rain/Snow/Wind
	FR	Pluie/Neige/Vent PM
	DE	Nachm. Regen/Schnee/Wind
	NL	midd. regen/sneeuw/winderig
	SE	em. regn/snö/blåst
	DA	em. Regn/Sne/Blæst

PLUGIN_WEATHERTIME_RAIN_SNOW_SHOWERS_WIND
	EN	Rain/Snow Showers/Wind
	FR	Pluie/Averses de Neige/Vent
	DE	Regen/Schneeschauer/Wind
	NL	regen/sneeubuien/winderig
	SE	Regn/snöbyar/blåst
	DA	Regn/Snebyger/Blæst

PLUGIN_WEATHERTIME_SNOW_SHOWER_WIND
	EN	Snow Showers/Wind
	DA	Snebyger/Blæst

PLUGIN_WEATHERTIME_RAIN_SNOW_WIND
	EN	Rain/Snow/Wind
	FR	Pluie/Neige/Vent
	DE	Regen/Schnee/Wind
	NL	regen/sneeuw/winderig
	SE	Regn/Snö/Blåst
	DA	Regn/Sne/Blæst

PLUGIN_WEATHERTIME_LIGHT_SNOW
	EN	Light Snow
	FR	Neige Légère
	DE	etwas Schnee
	NL	lichte sneeuw
	SE	Lätt snö
	DA	Let sne

PLUGIN_WEATHERTIME_PM_SNOW
	EN	PM Snow
	FR	Neige PM
	DE	Nachm. Schnee
	NL	midd. sneeuw
	SE	em. snö
	DA	em. sne

PLUGIN_WEATHERTIME_FEW_SNOW_SHOWERS_WIND
	EN	Few Snow Showers/Wind
	FR	Quelques Averses de Neige/Vent
	DE	wenige Schneeschauer/Wind
	NL	enkele sneeuwbuien/winderig
	SE	Spridda snöbyar/blåst
	DA	Få snebyger/blæst

PLUGIN_WEATHERTIME_LIGHT_SNOW_WIND
	EN	Light Snow/Wind
	FR	Neige/Vent Léger
	DE	etwas Schnee/Wind
	NL	lichte sneeuw/winderig
	SE	Lätt snö/blåst
	DA	Let sne/blæst

PLUGIN_WEATHERTIME_WINTRY_MIX
	EN	Wintry Mix
	FR	Mélange Hivernal
	DE	Winter-Mix
	NL	winters
	SE	Vinterväder
	DA	Vintervejr

PLUGIN_WEATHERTIME_AM_WINTRY_MIX
	EN	AM Wintry Mix
	FR	Mélange Hivernal AM
	DE	Vorm. Winter-Mix
	NL	ocht. winters
	SE	Vinterväder

PLUGIN_WEATHERTIME_HVY_RAIN_FREEZING_RAIN
	EN	Hvy Rain/Freezing Rain
	FR	Pluie Forte/Verglaçante
	DE	heftiger/gefr. Regen
	NL	sterke (ijs)regen
	SE	Underkylt regn
	DA	Hård/Frysende regn

PLUGIN_WEATHERTIME_AM_LIGHT_SNOW
	EN	AM Light Snow
	FR	Neige Légère AM
	DE	Vorm. etwas Schnee
	NL	ocht. enige sneeuw
	SE	Tidigt lätt snöfall
	DA	fm. let sne

PLUGIN_WEATHERTIME_RAIN_FREEZING_RAIN
	EN	Rain/Freezing Rain
	FR	Pluie/Pluie Verglaçante
	DE	Regen/gefr. Regen
	NL	regen/ijsregen
	SE	Regn/underkylt regn
	DA	Regn/Frysende regn

PLUGIN_WEATHERTIME_T-STORMS_WIND
	EN	T-Storms/Wind
	FR	Orages/Vent
	DE	Gewitter/Wind
	NL	onweer/winderig
	SE	Åskväder/blåst
	DA	Torden/Blæst

PLUGIN_WEATHERTIME_SPRINKLES
	EN	Sprinkles
	FR	Quelques Gouttes
	DE	Graupel
	NL	motregen
	SE	Strilregn
	DA	Silende regn

PLUGIN_WEATHERTIME_AM_SNOW_SHOWERS
	EN	AM Snow Showers
	FR	Averses de Neige AM
	DE	Vorm. Schneeschauer
	NL	ocht. sneeuwbuien
	SE	fm. snöfall
	DA	fm. snebyger

PLUGIN_WEATHERTIME_SNOW_SHOWERS_EARLY
	EN	Snow Showers Early
	FR	Averses de Neige Tôt
	DE	anfangs Schneeschauer
	NL	vroeg sneeuwbuien
	SE	fm. snöfall
	DA	fm. snebyger

PLUGIN_WEATHERTIME_AM_CLOUDS_PM_SUN_WIND
	EN	AM Clouds/PM Sun/Wind
	FR	Nuages AM / Soleil/Vent PM
	DE	Vorm. Wolken/Nachm. Sonne/Wind
	NL	bewolkt later zon/winderig
	SE	fm. mulet em. soligt/blåst
	DA	fm.skyet/em.sol/blæst

PLUGIN_WEATHERTIME_AM_RAIN_SNOW_WIND
	EN	AM Rain/Snow/Wind
	FR	Pluie/Neige/Vent AM
	DE	Vorm. Regen/Schnee/Wind
	NL	ocht. regen/sneeuw/winderig
	SE	fm. regn/snö/blåst
	DA	fm. regn/sne/blæst

PLUGIN_WEATHERTIME_RAIN_TO_SNOW_WIND
	EN	Rain to Snow/Wind
	FR	Pluie à Neige/Vent
	DE	Regen in Schnee überg./Wind
	NL	regen tot sneeuw/winderig
	SE	Regn till snö/blåst
	DA	Regn eller sne/blæst

PLUGIN_WEATHERTIME_SNOW_TO_WINTRY_MIX
	EN	Snow to Wintry Mix
	FR	Neige à Mélange Hivernal
	DE	Schnee in Winter-Mix überg.
	NL	sneeuw tot winters
	SE	Snö/vinterväder
	DA	Sne eller vintervejr

PLUGIN_WEATHERTIME_PM_SNOW_SHOWERS_WIND
	EN	PM Snow Showers/Wind
	FR	Averses de Neige/Vent PM
	DE	Nachm. Schneeschauer/Wind
	NL	midd. sneeuwbuien/winderig
	SE	fm. snöbyar
	DA	fm. snebyger/blæst

PLUGIN_WEATHERTIME_SNOW_AND_ICE_TO_RAIN
	EN	Snow and Ice to Rain
	FR	Neige et Glace à Pluie
	DE	Schnee und Hagel in Regen überg.
	NL	sneeuw/hagel tot regen
	SE	Snö till regn
	DA	Sne og Hagl eller regn

PLUGIN_WEATHERTIME_HEAVY_RAIN
	EN	Heavy Rain
	FR	Pluie Forte
	DE	heftiger Regen
	NL	zware buien
	SE	Regn
	DA	Hård regn

PLUGIN_WEATHERTIME_AM_RAIN_ICE
	EN	AM Rain/Ice
	FR	Pluie/Glace AM
	DE	Vorm. Regen/Hagel
	NL	ocht. regen/hagel
	SE	fm. regn/hagel
	DA	fm. regn/hagl

PLUGIN_WEATHERTIME_AM_SNOW_SHOWERS_WIND
	EN	AM Snow Showers/Wind
	FR	Averses de Neige/Vent AM
	DE	Vorm. Schneeschauer/Wind
	NL	ocht. sneeuwbuien/winderig
	SE	fm. regnbyar
	DA	fm. snebyger/blæst

PLUGIN_WEATHERTIME_AM_LIGH_SNOW_WIND
	EN	AM Light Snow/Wind
	FR	Neige Légère/Vent AM
	DE	Vorm. etwas Schnee/Wind
	NL	ocht. lichte sneeuw/winderig
	SE	fm. lätt snöfall
	DA	fm. let sne/blæst

PLUGIN_WEATHERTIME_PM_LIGHT_RAIN_WIND
	EN	PM Light Rain/Wind
	FR	Pluie Légère/Vent PM
	DE	Nachm. etwas Regen/Wind
	NL	midd. lichte regen/winderig
	SE	em. lätt regn/blåst
	DA	em. let regn/blæst

PLUGIN_WEATHERTIME_AM_LIGHT_WINTRY_MIX
	EN	AM Light Wintry Mix
	FR	Mélange Hivernal Léger AM
	DE	Vorm. leichter Winter-Mix
	NL	ocht. lichte winters
	SE	vinterväder
	DA	fm. let vintervejr

PLUGIN_WEATHERTIME_PM_LIGHT_SNOW_WIND
	EN	PM Light Snow/Wind
	FR	Neige Légère/Vent PM
	DE	Nachm. etwas Schnee/Wind
	NL	midd. lichte sneeuw/winderig
	SE	em. lätt snö/blåst
	DA	em. let sne/blæst

PLUGIN_WEATHERTIME_HEAVY_RAIN_WIND
	EN	Heavy Rain/Wind
	FR	Pluie/Vent Forts
	DE	heftiger Regen/Wind
	NL	zware regen/winderig
	SE	Regn/blåst
	DA	Hård regn/blæst

PLUGIN_WEATHERTIME_PM_SNOW_SHOWER
	EN	PM Snow Shower
	FR	Averse de Neige PM
	DE	Nachm. Schneeschauer
	NL	midd. sneeuwbui
	SE	em. snöfall
	DA	em. snebyger

PLUGIN_WEATHERTIME_PM_SNOW_SHOWERS
	EN	PM Snow Showers
	FR	Averses de Neige PM
	DE	Nachm. Schneeschauer
	NL	midd. sneeuwbuien
	SE	em. snöfall
	DA	em. snebyger

PLUGIN_WEATHERTIME_SNOW_SHOWERS_LATE
	EN	Snow Showers Late
	FR	Averses de Neige Tard
	DE	Abends Schneeschauer
	NL	avond sneeuwbui
	SE	em. snöfall
	DA	em. snebyger

PLUGIN_WEATHERTIME_RAIN_SNOW_SHOWERS_LATE
	EN	Rain / Snow Showers Late
	FR	Pluie / Averses de Neige Tard
	DE	Regen / Abends Schneeschauer
	NL	Regen later sneeuwbuien
	SE	em. regn/snö
	DA	em. regn/sne-byger

PLUGIN_WEATHERTIME_SNOW_TO_RAIN_WIND
	EN	Snow to Rain/Wind
	FR	Neige à Pluie/Vent
	DE	Schnee in Regen überg./Wind
	NL	sneeuw tot regen/winderig
	SE	Snö till regn/blåst
	DA	Sne eller regn/blæst

PLUGIN_WEATHERTIME_PM_LIGHT_RAIN_ICE
	EN	PM Light Rain/Ice
	FR	Pluie/Glace Léger PM
	DE	Nachm. leichter Regen/Hagel
	NL	midd. lichte regen/hagel
	SE	em. lätt regn
	DA	em. let regn/hagl

PLUGIN_WEATHERTIME_SNOW
	EN	Snow
	FR	Neige
	DE	Schnee
	NL	sneeuw
	SE	Snö
	DA	Sne
	
PLUGIN_WEATHERTIME_AM_SNOW
	EN	AM Snow
	FR	Neige AM
	DE	Vorm. Schnee
	NL	ocht. sneeuw
	SE	fm. snö
	DA	fm. sne

PLUGIN_WEATHERTIME_SNOW_TO_ICE
	EN	Snow to Ice
	FR	Neige à Glace
	DE	Schnee in Hagel überg.
	NL	sneeuw tot hagel
	SE	Snö til hagel
	DA	Sne eller hagl

PLUGIN_WEATHERTIME_WINTRY_MIX_WIND
	EN	Wintry Mix/Wind
	FR	Mélange Hivernal/Vent
	DE	Winter-Mix/Wind
	NL	winters/winderig
	SE	Vinterväder/blåst
	DA	Vintervejr/blæst

PLUGIN_WEATHERTIME_PM_LIGHT_SNOW
	EN	PM Light Snow
	FR	Neige Légère PM
	DE	Nachm. etwas Schnee
	NL	midd. enige sneeuw
	SE	fm. lätt snö
	DA	fm. let sne

PLUGIN_WEATHERTIME_AM_DRIZZLE
	EN	AM Drizzle
	FR	Bruine AM
	DE	Vorm. Nieselregen
	NL	ocht. motregen
	SE	fm. duggregn
	DA	fm. småregn

PLUGIN_WEATHERTIME_STRONG_STORMS_WIND
	EN	Strong Storms/Wind
	FR	Fortes Tempêtes/Vent
	DE	starke Stürme/Wind
	NL	zware storm/winderig
	SE	Stormbyar
	DA	Hård storm

PLUGIN_WEATHERTIME_PM_DRIZZLE
	EN	PM Drizzle
	FR	Bruine PM
	DE	Nachm. Nieselregen
	NL	middag motregen
	SE	em. duggregn
	DA	em. smÅregn

PLUGIN_WEATHERTIME_DRIZZLE
	EN	Drizzle
	FR	Bruine
	DE	Nieselregen
	NL	motregen
	SE	Smågregn
	DA	småregn

PLUGIN_WEATHERTIME_AM_LIGHT_RAIN_WIND
	EN	AM Light Rain/Wind
	FR	Pluie/Vent Légers AM
	DE	Vorm. etwas Regen/Wind
	NL	ocht. lichte regen/winderig
	SE	fm. lätt regn
	DA	fm. let Regn/Blæst

PLUGIN_WEATHERTIME_AM_RAIN_WIND
	EN	AM Rain/Wind
	FR	Pluie/vent AM
	DE	Vorm. Regen/Wind
	NL	ocht. regen/winderig
	SE	fm. regn/blåst
	DA	fm. Regn/Blæst

PLUGIN_WEATHERTIME_WINTRY_MIX_TO_SNOW
	EN	Wintry Mix to Snow
	FR	Mélange Hivernal à Neige
	DE	Winter-Mix in Schnee überg.
	NL	winters tot sneeuw
	SE	Vinterväder / snö
	DA	Vintervejr måske sne

PLUGIN_WEATHERTIME_SNOW_SHOWERS_WINDY
	EN	Snow Showers/Windy
	FR	Averses de Neige/Venteux
	DE	Schneeschauer/Wind
	NL	sneeuwbuien/winderig
	SE	Snöfall/blåst
	DA	Snebyger/Blæst

PLUGIN_WEATHERTIME_LIGHT_RAIN_SHOWER
	EN	Light Rain Shower
	FR	Averse de Pluie Légère
	DE	leichte Regenschauer
	NL	lichte regenbui
	SE	Lätta regnskurar
	DA	Lette regnbyger

PLUGIN_WEATHERTIME_LIGHT_RAIN_WITH_THUNDER
	EN	Light Rain with Thunder
	FR	Pluie Légère avec Tonerre
	DE	etwas Regen mit Donner
	NL	lichte regen met donder
	SE	Lätt regn med åska
	DA	Let regn med torden

PLUGIN_WEATHERTIME_LIGHT_DRIZZLE
	EN	Light Drizzle
	FR	Bruine Légère
	DE	leichter Nieselregen
	NL	lichte motregen
	SE	Lätt duggregn
	DA	Let småregn

PLUGIN_WEATHERTIME_DRIZZLE_LATE
	EN	Drizzle late
	DA	Småregn sent

PLUGIN_WEATHERTIME_MIST
	EN	Mist
	FR	Brume
	DE	Nebel
	NL	mist
	SE	Dimma
	DA	Tåget

PLUGIN_WEATHERTIME_SMOKE
	EN	Smoke
	FR	Fumée
	DE	Rauch
	NL	smoke
	SE	Rök
	DA	Smog

PLUGIN_WEATHERTIME_HAZE
	EN	Haze
	FR	Brume
	DE	Dunst
	NL	heiig
	SE	Dis
	DA	Hagl

PLUGIN_WEATHERTIME_LIGHT_SNOW_SHOWER
	EN	Light Snow Shower
	FR	Averse de Neige Légère
	DE	leichte Schneeschauer
	NL	lichte sneeuwbui
	SE	Lätt snöfall
	DA	Let sne

PLUGIN_WEATHERTIME_LIGHT_SNOW_SHOWER_WINDY
	EN	Light Snow Shower/ Windy
	FR	Averse de Neige Légère/ Venteux
	DE	leichte Schneeschauer/Wind
	NL	lichte sneeuwbui/winderig
	SE	Lätt snöfall / blåst
	DA	Let sne/blæst

PLUGIN_WEATHERTIME_CLEAR
	EN	Clear
	FR	Dégagé
	DE	Klar
	NL	helder
	SE	Klart
	DA	Klart

PLUGIN_WEATHERTIME_MOSTLY_CLEAR
	EN	Mostly Clear
	FR	Plutôt Dégagé
	DE	Meist klar
	NL	meestal helder
	SE	Mestadels klart
	DA	Mest klart

PLUGIN_WEATHERTIME_A_FEW_CLOUDS
	EN	A Few Clouds
	FR	Quelques Nuages
	DE	wenige Wolken
	NL	enkele wolken
	SE	enstaka moln
	DA	Enkelte skyer

PLUGIN_WEATHERTIME_FAIR
	EN	Fair
	FR	Agréable
	DE	Freundlich
	NL	redelijk
	SE	Klart
	DA	Klart

PLUGIN_WEATHERTIME_PM_T-SHOWERS
	EN	PM T-Showers
	FR	Orages PM
	DE	Nachm. gewittrige Schauer
	NL	midd. onweersbui
	SE	em. skurar med åska
	DA	em. Tordenbyger

PLUGIN_WEATHERTIME_T-SHOWERS
	EN	T-Showers
	FR	Orages
	DE	gewittrige Schauer
	NL	onweersbui
	SE	Åskskurar
	DA	Tordenbyger

PLUGIN_WEATHERTIME_T-SHOWERS_WIND
	EN	T-Showers / Wind
	FR	Orages / Vent
	DE	gewittrige Schauer/Wind
	NL	onweersbui/winderig
	SE	Åskskurar
	DA	Tordenbyger/Blæst

PLUGIN_WEATHERTIME_T-STORMS_EARLY
	EN	T-Storms early
	FR	Orages en matinée
	DE	anfangs Gewitter
	NL	vroeg onweer
	SE	Tidiga åskskurar
	DA	Tidlig tordenbyger

PLUGIN_WEATHERTIME_LIGHT_RAIN_EARLY
	EN	Light Rain Early
	FR	Pluie légère en matinée
	DE	anfangs leichter Regen
	NL	vroeg lichte buien
	SE	fm. duggregn
	DA	fm. let regn

PLUGIN_WEATHERTIME_SUNNY_WIND
	EN	Sunny/Wind
	FR	Ensoleillé/Venteux
	DE	sonnig/Wind
	NL	zonnig/winderig
	SE	Soligt/blåst
	DA	Solrigt/Blæsende
	
PLUGIN_WEATHERTIME_FOGGY
	EN	Foggy
	DE	nebelig
	SE	dimma
	DA	Tåge
	
PLUGIN_WEATHERTIME_PM_FOG
	EN	PM Fog
	DE	nachmittags Nebel
	SE	em. dimma
	DA	em. Tåge
	
PLUGIN_WEATHERTIME_AM_FOG_PM_SUN
	EN	AM Fog / PM Sun
	DE	vorm. Nebel/nachm. Sonne
	SE	fm. dimma em. sol
	DA	fm. Tåge/em. Sol

PLUGIN_WEATHERTIME_DRIZZLE_FOG
	EN	Drizzle/Fog
	DE	Nieselregen/Nebel
	SE	duggregn / dimma
	DA	let småregn/Tåge
	
PLUGIN_WEATHERTIME_LIGHT_RAIN_FOG
	EN	Light Rain/Fog
	DE	leichter Regen/Nebel
	SE	duggregn / dimma
	DA	Let regn/tåge

PLUGIN_WEATHERTIME_AM_FOG_PM_CLOUDS
	EN	AM Fog / PM Clouds
	DE	vorm. Nebel/nachm. Wolken
	DA	fm. Tåge/em. Skyet
	
PLUGIN_WEATHERTIME_WIND_0
	EN	m/s
	DA	m/s
	DE	m/s
	
PLUGIN_WEATHERTIME_WIND_1
	EN	km/h
	DA	km/t
	DE	km/h
	
PLUGIN_WEATHERTIME_WIND_2
	EN	mph
	DA	m/t
	DE	mi/h
	
PLUGIN_WEATHERTIME_WIND_N
	EN	N
	DA	N
	DE	N
	
PLUGIN_WEATHERTIME_WIND_NNE
	EN	NNE
	DA	NNØ
	DE	NNO

PLUGIN_WEATHERTIME_WIND_NE
	EN	NE
	DA	NØ
	DE	NO

PLUGIN_WEATHERTIME_WIND_ENE
	EN	ENE
	DA	ØNØ
	DE	ONO

PLUGIN_WEATHERTIME_WIND_E
	EN	East
	DA	Øst
	DE	Ost
	
PLUGIN_WEATHERTIME_WIND_ESE
	EN	ESE
	DA	ØSØ
	DE	OSO

PLUGIN_WEATHERTIME_WIND_SE
	EN	SE
	DA	SØ
	DE	SO

PLUGIN_WEATHERTIME_WIND_SSE
	EN	SSE
	DA	SSØ
	DE	SSO

PLUGIN_WEATHERTIME_WIND_S
	EN	S
	DA	Syd
	DE	Süd
	
PLUGIN_WEATHERTIME_WIND_SSW
	EN	SSW
	DA	SSV
	DE	SSW
	
PLUGIN_WEATHERTIME_WIND_SW
	EN	SW
	DA	SV
	DE	SW
	
PLUGIN_WEATHERTIME_WIND_WSW
	EN	WSW
	DA	VSV
	DE	WSW

PLUGIN_WEATHERTIME_WIND_W
	EN	W
	DA	V
	DE	W
		
PLUGIN_WEATHERTIME_WIND_WNW
	EN	WNW
	DA	VNV
	DE	WNW

PLUGIN_WEATHERTIME_WIND_NW
	EN	NW
	DA	NV
	DE	NW

PLUGIN_WEATHERTIME_WIND_NNW
	EN	NNW
	DA	NNV
	DE	NNW

PLUGIN_WEATHERTIME_WIND_ALL
	EN	ALL
	DA	NSØV
	DE	NSOW
	
PLUGIN_WEATHERTIME_SUNRISE
	EN	Sunrise
	DE	Sonnenaufgang
	DA	Solopgang
	
PLUGIN_WEATHERTIME_SUNSET
	EN	Sunset
	DE	Sonnenuntergang
	DA	Solnedgang

PLUGIN_WEATHERTIME_HUMID
	EN	Humidity
	DE	Luftfeuchtigkeit
	DA	Luftfugtighed
	
PLUGIN_WEATHERTIME_WINDGUST
	EN	Windgust
	DE	Böen
	DA	Vindstød
	
PLUGIN_WEATHERTIME_CURRENTBAR
	EN	Presure
	DE	Luftdruck
	DA	Tryk

PLUGIN_WEATHERTIME_CURRENTBAR_FALLING
	EN	Falling
	DE	fallend
	DA	Faldende

PLUGIN_WEATHERTIME_CURRENTBAR_RISING
	EN	Rising
	DE	steigend
	DA	Stigende

PLUGIN_WEATHERTIME_CURRENTBAR_STEADY
	EN	Steady
	DE	konstant
	DA	Stabilt

PLUGIN_WEATHERTIME_CURRENTBAR_N_A
	EN	N/A
	DE	unbekannt
	DA	Ukendt

PLUGIN_WEATHERTIME_VISIBILITY
	EN	Visibility
	DA	Sigtbarhed

PLUGIN_WEATHERTIME_UVINDEX
	EN	UV-index
	DE	UV-Index
	DA	UV-index

PLUGIN_WEATHERTIME_UVINDEX_
	EN	Low
	DE	niedrig
	DA	Lavt

PLUGIN_WEATHERTIME_UVINDEX_LOW
	EN	Low
	DE	niedrig
	DA	Lavt

PLUGIN_WEATHERTIME_MOON
	EN	Moon
	DE	Mond
	DA	Måne

PLUGIN_WEATHERTIME_MOON_NEW
	EN	New
	DE	Neu
	DA	Ny
			
PLUGIN_WEATHERTIME_MOON_FULL
	EN	Full
	DE	Voll
	DA	Fuld

PLUGIN_WEATHERTIME_MOON_FIRST_QUARTER
	EN	First quarter
	DA	Tiltagende (halv)

PLUGIN_WEATHERTIME_MOON_THIRD_QUARTER
	EN	Third quarter
	DA	Aftagende (halv)

PLUGIN_WEATHERTIME_MOON_WAXING_GIBBOUS
	EN	Waxing gibbous
	DA	Tiltagende (stor)

PLUGIN_WEATHERTIME_MOON_LAST_QUARTER
	EN	Last quarter
	DA	Aftagende (lille)

PLUGIN_WEATHERTIME_MOON_WAXING_CRESCENT
	EN	Waxing crescent
	DA	Tiltagende (lille) 

PLUGIN_WEATHERTIME_MOON_WANING_GIBBOUS
	EN	Waning gibbous
	DA	Aftagende (stor)

PLUGIN_WEATHERTIME_MOON_WANING_CRESCENT
	EN	Waning crescent
	DA	Aftagende (lille)

PLUGIN_WEATHERTIME_FOG_LATE
	EN	Fog Late
	DE	abends Nebel
	DA	Aften tåge
	
PLUGIN_WEATHERTIME_FOGGY_WIND
	EN	Foggy / Wind
	DE	Neblig / Wind
	DA	Tåge / Blæst

PLUGIN_WEATHERTIME_WIND_CALM
	EN	Wind calm
	DE	Wind ruhig
	DA	Let blæst

PLUGIN_WEATHERTIME_WIND_VAR
	EN	Wind var
	DE	Wind variabel
	DA	blæst skiftende

PLUGIN_WEATHERTIME_CHANCE_OF_RAIN
	EN	Chance of Rain
	DE	Regen möglich

PLUGIN_WEATHERTIME_SCATTERED_CLOUDS
	EN	Scattered Clouds
	DE	Teils wolkig
	FR	Partiellement nuageux
	NL	halfbewolkt
	SE	Halvklart
	DA	Let skyet
';}

1;
